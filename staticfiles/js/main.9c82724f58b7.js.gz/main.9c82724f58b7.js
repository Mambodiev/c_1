

// end hero slide
//   language
// $('.selectpicker').on('change', function () {
// 	$(this).closest('form').submit();
//   });
//   end language


